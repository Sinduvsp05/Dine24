import random
import json
import torch
from flask import Flask, request, jsonify
from model import NeuralNet
from nltk_utils import bag_of_words, tokenize
from flask_cors import CORS
# Add CORS to allow cross-origin requests
app = Flask(__name__)
CORS(app)  # This will allow requests from any origin

# Set device for PyTorch (CUDA or CPU)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load intents and model data
with open('intents.json', 'r') as json_data:
    intents = json.load(json_data)

FILE = "data.pth"
data = torch.load(FILE, weights_only=True)

input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
all_words = data['all_words']
tags = data['tags']
model_state = data["model_state"]

# Initialize the model
model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)  # Load only model weights
model.eval()

# Route for the chatbot to interact with users
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message')

    if not user_message:
        return jsonify({"response": "No message received."}), 400

    try:
        # Tokenize and process the input sentence
        tokenized_message = tokenize(user_message)
        X = bag_of_words(tokenized_message, all_words)
        X = X.reshape(1, X.shape[0])
        X = torch.from_numpy(X).to(device)

        # Get the model's response
        with torch.no_grad():
            output = model(X)
            _, predicted = torch.max(output, dim=1)

        tag = tags[predicted.item()]
        probs = torch.softmax(output, dim=1)
        prob = probs[0][predicted.item()]

        # Check if the probability is above the threshold
        if prob.item() > 0.75:
            for intent in intents['intents']:
                if tag == intent["tag"]:
                    response = random.choice(intent['responses'])
                    print(f"Bot Response: {response}")  # Print the response in the console
                    return jsonify({"response": response}), 200
        else:
            response = "I do not understand..."
            print(f"Bot Response: {response}")  # Print the response in the console
            return jsonify({"response": response}), 200

    except Exception as e:
        print(f"Error processing message: {e}")
        return jsonify({"response": "Sorry, there was an error with the chatbot."}), 500


# Main entry point to run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
