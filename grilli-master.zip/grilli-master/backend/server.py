from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from datetime import datetime
import traceback
from flask_cors import CORS  # Import CORS

# Import necessary libraries for the model-based chatbot
import random
import json
import torch
from model import NeuralNet
from nltk_utils import bag_of_words, tokenize

app = Flask(__name__)

# Enable CORS for the entire app (this should handle OPTIONS as well)
CORS(app, supports_credentials=True)

# MongoDB URI (if you have a MongoDB setup)
app.config["MONGO_URI"] = "mongodb://localhost:27017/reservations"
mongo = PyMongo(app)

# Set device for PyTorch (CUDA or CPU)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load intents and model data
with open('intents.json', 'r') as json_data:
    intents = json.load(json_data)

FILE = "data.pth"
data = torch.load(FILE, weights_only=True)

input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
all_words = data['all_words']
tags = data['tags']
model_state = data["model_state"]

# Initialize the model
model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)  # Load only model weights
model.eval()

# Function to check if a time slot is available
def is_time_slot_available(reservation_date, reservation_time):
    # Count the number of reservations for the given date and time
    count = mongo.db.reservations.count_documents({
        "reservation_date": reservation_date,
        "reservation_time": reservation_time
    })
    return count < 5

@app.route('/api/reservations', methods=['POST', 'OPTIONS'])
def make_reservation():
    if request.method == 'OPTIONS':
        # Respond to preflight request
        return '', 200  # Empty response with a 200 OK status for preflight (OPTIONS) requests

    try:
        data = request.json
        print("Received data:", data)

        # Extract reservation data
        name = data.get("name")
        phone = data.get("phone")
        person = data.get("person")
        reservation_date = data.get("reservationDate")
        reservation_time = data.get("reservationTime")
        message = data.get("message")

        # Validation
        if not name or not phone or not person or not reservation_date or not reservation_time:
            return jsonify({"success": False, "message": "All fields are required!"}), 400

        # Validate date format
        try:
            reservation_date = datetime.strptime(reservation_date, "%Y-%m-%d")
        except ValueError:
            return jsonify({"success": False, "message": "Invalid date format!"}), 400

        # Check if the time slot is available (less than 5 reservations)
        if not is_time_slot_available(reservation_date, reservation_time):
            return jsonify({"success": False, "message": "This time slot is already fully booked. Please choose another time."}), 400

        # Insert reservation into MongoDB
        reservation = {
            "name": name,
            "phone": phone,
            "person": person,
            "reservation_date": reservation_date,
            "reservation_time": reservation_time,
            "message": message,
        }

        mongo.db.reservations.insert_one(reservation)
        return jsonify({"success": True, "message": "Thank you for your reservation!"}), 200

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return jsonify({"success": False, "message": "Failed to submit reservation. Please try again."}), 500


@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get("message")
        print("User message:", user_message)  # Print user message to the terminal

        if not user_message:
            return jsonify({"response": "No message received."}), 400

        # Tokenize and process the input sentence
        tokenized_message = tokenize(user_message)
        X = bag_of_words(tokenized_message, all_words)
        X = X.reshape(1, X.shape[0])
        X = torch.from_numpy(X).to(device)

        # Get the model's response
        with torch.no_grad():
            output = model(X)
            _, predicted = torch.max(output, dim=1)

        tag = tags[predicted.item()]
        probs = torch.softmax(output, dim=1)
        prob = probs[0][predicted.item()]

        # Check if the probability is above the threshold
        if prob.item() > 0.75:
            for intent in intents['intents']:
                if tag == intent["tag"]:
                    response = random.choice(intent['responses'])
                    print(f"Bot Response: {response}")  # Print the response in the console
                    return jsonify({"response": response}), 200
        else:
            response = "I do not understand..."
            print(f"Bot Response: {response}")  # Print the response in the console
            return jsonify({"response": response}), 200

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return jsonify({"response": "Sorry, there was an error with the chatbot."}), 500


if __name__ == '__main__':
    app.run(debug=True)
