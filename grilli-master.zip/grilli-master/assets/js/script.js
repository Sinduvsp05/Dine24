'use strict';

/**
 * PRELOAD
 * 
 * loading will be end after document is loaded
 */
const preloader = document.querySelector("[data-preaload]");

window.addEventListener("load", function () {
  preloader.classList.add("loaded");
  document.body.classList.add("loaded");
});

/**
 * add event listener on multiple elements
 */
const addEventOnElements = function (elements, eventType, callback) {
  for (let i = 0, len = elements.length; i < len; i++) {
    elements[i].addEventListener(eventType, callback);
  }
}

/**
 * RESERVATION FORM SUBMISSION
 */
const form = document.querySelector("#reservationForm"); // Ensure this matches the HTML

form.addEventListener("submit", function (event) {
  event.preventDefault(); // Prevent default form submission

  // Get form data
  const formData = new FormData(form);
  const reservationData = {
    name: formData.get("name"),
    phone: formData.get("phone"),
    person: formData.get("person"),
    reservationDate: formData.get("reservation-date"),
    reservationTime: formData.get("reservation-time"),
    message: formData.get("message"),
  };

  // Log the data to check
  console.log(reservationData);

  // Validation: Check if required fields are filled
  if (!reservationData.name || !reservationData.phone || !reservationData.person || !reservationData.reservationDate || !reservationData.reservationTime) {
    alert("Please fill in all required fields.");
    return;
  }

  // Send the data to Flask backend via fetch
  fetch("http://127.0.0.1:5000/api/reservations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(reservationData),
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message);  // Show success message from backend
        form.reset();  // Reset the form fields after successful submission
      } else {
        alert("There was an error: " + data.message);
      }
    })
    .catch(error => {
      console.error("Error:", error);
      alert("Failed to submit reservation.");
    });
});

/**
 * NAVBAR
 */
const navbar = document.querySelector("[data-navbar]");
const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const overlay = document.querySelector("[data-overlay]");

const toggleNavbar = function () {
  navbar.classList.toggle("active");
  overlay.classList.toggle("active");
  document.body.classList.toggle("nav-active");
}

addEventOnElements(navTogglers, "click", toggleNavbar);

/**
 * HEADER & BACK TOP BTN
 */
const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

let lastScrollPos = 0;

const hideHeader = function () {
  const isScrollBottom = lastScrollPos < window.scrollY;
  if (isScrollBottom) {
    header.classList.add("hide");
  } else {
    header.classList.remove("hide");
  }

  lastScrollPos = window.scrollY;
}

window.addEventListener("scroll", function () {
  if (window.scrollY >= 50) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
    hideHeader();
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
});

/**
 * CHATBOT FUNCTIONALITY
 */

// Chatbot toggle functionality
const chatbotToggle = document.getElementById("chatbot-toggle");
const chatbotContainer = document.getElementById("chatbot");
const chatbotClose = document.getElementById("chatbot-close");
const sendButton = document.getElementById("send-button");
const userInput = document.getElementById("user-input");
const chatbotMessages = document.getElementById("chatbot-messages");

// Show/hide chatbot on toggle
chatbotToggle.addEventListener("click", function () {
    chatbotContainer.style.display = "block"; // Show chatbot
});

chatbotClose.addEventListener("click", function () {
    chatbotContainer.style.display = "none"; // Hide chatbot
});

// Send message to the chatbot
sendButton.addEventListener("click", function () {
  const userMessage = userInput.value;
  if (userMessage.trim() === "") return; // Prevent sending empty messages

  // Display user's message
  displayMessage("You: " + userMessage, "user");
  console.log("User message:", userMessage);  // Debugging line
  // Clear the input field
  userInput.value = "";

  // Send user message to the backend
  fetch("http://127.0.0.1:5000/chat", {
      method: "POST",
      headers: {
          "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: userMessage }),
  })
      .then(response => response.json())
      .then(data => {
          // Display chatbot's response
          console.log("Response from bot:", data);  // Debugging line
          displayMessage("Bot: " + data.response, "bot");
      })
      .catch(error => {
          console.error("Error:", error);
          displayMessage("Bot: Sorry, there was an error.", "bot");
      });
});

// Function to display messages in the chatbot
function displayMessage(message, sender) {
  console.log("Displaying message:", message);  // Debugging line
  const messageElement = document.createElement("div");
  messageElement.classList.add(sender === "user" ? "user-message" : "bot-message");
  messageElement.textContent = message;
  chatbotMessages.appendChild(messageElement);
  chatbotMessages.scrollTop = chatbotMessages.scrollHeight;  // Auto-scroll to bottom
}
